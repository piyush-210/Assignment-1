var inputarea=document.getElementById("input-area");

var count=4;

inputarea.addEventListener("keyup",function(e){
    if(e.code=="Enter" && inputarea.value!="")
    {
        count++;

        var task=document.createElement("div");
        task.setAttribute("class","task");
        
        task.appendChild(document.createTextNode(inputarea.value));
        
        var icon=document.createElement("i");
        icon.setAttribute("class","fas fa-trash-alt");
        icon.setAttribute("id","delete-"+count);
        task.appendChild(icon);

        icon=document.createElement("i");
        icon.setAttribute("class","fas fa-check com");
        icon.setAttribute("id","check-"+count);
        task.appendChild(icon);

        icon=document.createElement("i");
        icon.setAttribute("class","fa fa-plus-circle com");
        task.appendChild(icon);

        icon=document.createElement("i");
        icon.setAttribute("class","fas fa-arrow-down com");
        icon.setAttribute("id","down-"+count);
        task.appendChild(icon);

        icon=document.createElement("i");
        icon.setAttribute("class","fas fa-arrow-up com");
        icon.setAttribute("id","up-"+count);
        task.appendChild(icon);

        var notdone=document.getElementsByClassName("notdone")[0];

        notdone.appendChild(task);

    }
});

var notdone=document.getElementsByClassName("notdone");
var complete=document.getElementsByClassName("complete");
notdone[0].onclick=function(e){
    if(e.srcElement.id.includes("delete"))
    {
        var parent=document.getElementById(e.srcElement.id).parentNode;
        console.log(parent);
        parent.parentNode.removeChild(parent);
    }

    if(e.srcElement.id.includes("check"))
    {
        var element=document.getElementById(e.srcElement.id);
        var parent=element.parentNode;
        document.getElementsByClassName("com")[0].style.display="none";
        document.getElementsByClassName("com")[1].style.display="none";
        document.getElementsByClassName("com")[2].style.display="none";
        document.getElementsByClassName("com")[3].style.display="none";
        complete[0].appendChild(parent);
        notdone[0].removeChild(parent);
    }

    if(e.srcElement.id.includes("up"))
    {
        var element=document.getElementById(e.srcElement.id).parentNode;
        console.log(element.parentNode);
        if(element.previousElementSibling && element.previousElementSibling!=element.parentNode.firstChild)
        {
            element.parentNode.insertBefore(element, element.previousElementSibling);
        }
    }

    if(e.srcElement.id.includes("down"))
    {
        var element=document.getElementById(e.srcElement.id).parentNode;
        if(element.nextElementSibling)
        {
            element.parentNode.insertBefore(element.nextElementSibling, element);
        }
    }
}

complete[0].onclick=function(e){
    if(e.srcElement.id.includes("delete"))
    {
        var parent=document.getElementById(e.srcElement.id).parentNode;
        console.log(parent);
        parent.parentNode.removeChild(parent);
    }
}